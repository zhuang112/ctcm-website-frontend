# 中台世界專案協作工作流程（User / ChatGPT / 實作 Agent）

> 版本：2025-12-09（由 ChatGPT 更新）

> 目標：讓你只需要做關鍵決策與簡單 copy / paste，  
> 技術細節與執行由 ChatGPT + Windsurf 自動接力完成。

---

## 1. 角色分工與單一真相來源

### 1.1 你（使用者）

- 決定 **做什麼**、**先做哪個**。
- 在 ChatGPT 與 Windsurf 之間負責「簡單傳遞」：
  - 把 ChatGPT 給 Windsurf 的指令貼給 Windsurf。
  - 把 Windsurf 的「回報摘要」貼給 ChatGPT。
- 偶爾執行本機操作：
  - `git add / commit / push`
  - 必要時手動執行 `npm install` 等需要確認的指令。
- 確保 GitHub repo 永遠是 **唯一真相來源**（程式碼 + docs）。

### 1.2 ChatGPT（架構師＋規格機）

- 負責「設計」與「規格」：
  - 規劃整體架構、欄位、流程。
  - 撰寫與更新 `docs/*.md` 規格（大改時會提供 ZIP）。
- 負責「寫任務說明」：
  - 對每個任務產生一段 **「可直接貼給 Windsurf 的指令」**（code block）。
  - 指令包含：
    - 要看哪些 docs。
    - 要改哪些檔案。
    - 不能改動的型別 / 規則。
    - 要跑哪些測試與預期結果。
- 負責「技術決策與 debug 指導」：
  - 閱讀 Windsurf 寫的 notes / 回報，決定下一步。
  - 遇到難題時，設計更精細的修改指令。

### 1.3 Windsurf（實作者＋本機工具）

### 1.4 實作 Agent：Windsurf / Codex 共通規則

> 本文件中提到的「實作 Agent」包含：
> - 目前的 Windsurf（在你本機 repo 上修改檔案）  
> - 未來可能加入的 Codex / 其他工程 Agent（通常在雲端 sandbox 上操作，透過 GitHub PR 或 patch 回傳結果）

共通原則：

- 任何實作 Agent **都必須以 GitHub repo 的檔案為準**，不得自行想像檔案內容。
- ChatGPT **看不到 GitHub / sandbox 內部檔案**，只看得到：
  - 你貼進聊天視窗的文字片段。
  - 你上傳給 ChatGPT 的檔案（例如：`docs/` snapshot ZIP、單一 `.md` 檔、log 檔）。
- 若需要 ChatGPT 針對某次實作給建議或調整：
  - 請由實作 Agent 在 repo 中更新相關 docs（例如 `docs/Windsurf_ChatGPT_NOTES.md`、`docs/PROJECT_TODO.md`、`docs/PENDING_DECISIONS.md`）。
  - 由你將更新後的 docs（或打包好的 ZIP）上傳給 ChatGPT。
- 無論是 Windsurf 還是 Codex，結束任務時都應該：
  - 更新對應的 T 任務狀態（`docs/PROJECT_TODO.md`）。
  - 在 notes 中留下清楚的「這次做了什麼」紀錄（`docs/Windsurf_ChatGPT_NOTES.md`）。
  - 視需要在 `docs/PENDING_DECISIONS.md` 記錄尚未正式寫入 workflow / schema 的暫存決策。


- 負責「實際動手」：
  - 編輯程式碼與測試。
  - 儘量自動執行安全的指令（`npx vitest`、`npm run lint`…）。
- 負責「寫給 ChatGPT 看的說明檔」：
  - 維護 `docs/Windsurf_ChatGPT_NOTES.md`：
    - 記錄每次任務的需求摘要、修改內容、測試、遇到的問題。
- 負責「回報摘要」：
  - 每次任務結束，輸出一段 **可以給你直接貼回 ChatGPT 的短回報文字**。

---

## 2. 主要協作文件一覽

這些檔案是三方協作時會用到的主要文件：

- `docs/COMPLETE_PROJECT_WORKFLOW.md`  
  舊站 HTML → JSON → zh-cn → WordPress → React 的整體 pipeline。

- `docs/CONTENT_SCHEMA.md`  
  各 post_type 的 AnyContent schema（欄位與說明）。

- `docs/HTML_TO_MARKDOWN_RULES_V4.md`  
  HTML→Markdown 規則與舊站 class 對應（目前唯一權威版本）。

- `docs/PROJECT_TODO.md`  
  中長期任務清單（T-001, T-002...），**由 ChatGPT 維護**。

- `docs/Windsurf_ChatGPT_NOTES.md`  
  **三方交接日誌**：每一次 Windsurf 實作的詳細紀錄，  
  ChatGPT 開新對話時可以讀這個檔案快速接續。

- （選用）`docs/UNRESOLVED_ISSUES.md`  
  Windsurf 解不了的問題集中列出，給 ChatGPT 進一步協助。  
  若同一時間有多個未解決問題，建議在 UNRESOLVED_ISSUES.md 做列表索引，並連回各自於 `Windsurf_ChatGPT_NOTES.md` 中的任務小節，方便你與 ChatGPT 快速定位。

---

> **重要原則：ChatGPT 一律以 GitHub repo 的最新內容為「唯一權威來源」**  
> - repo：<https://github.com/zhuang112/ctcm-website-frontend>  
> - 若同時存在使用者提供的本機 zip / snippet，這些僅視為「補充範例」或「暫時 snapshot」，不能覆蓋 GitHub docs 的定義。  
> - 除非使用者明講「這個 zip 代表一個暫時還沒 push 的 snapshot，請以它為準」，否則 ChatGPT 必須優先閱讀 GitHub 上的 docs（特別是 `PROJECT_TODO.md`、`CONTENT_SCHEMA.md`、`WORKFLOW_CHATGPT_GITHUB_WINDSURF.md`、`Windsurf_ChatGPT_NOTES.md`）。  

## 3. 大改 vs 小改：什麼時候需要 ZIP？什麼時候用指令？

### 3.1 大改（spec / workflow / schema）

符合下列任一者視為「大改」：

- 調整 `CONTENT_SCHEMA.md` 結構（新增欄位、改欄位意義）。
- 大幅更新 `HTML_TO_MARKDOWN_RULES_V4.md` 的規則。
- 新增新的 post_type 或 pipeline 大架構。
- 更新協作流程本身（像這份文件）。

**大改流程：**

1. 由 ChatGPT：
   - 在對話中簡短說明這次大改的重點。
   - 直接編寫 / 更新對應 `docs/*.md` 的完整內容。
   - 將相關 docs 打成 ZIP（例如 `ctworld_docs_xxx.zip`）給你下載。

2. 你：
   - 解壓 ZIP 覆蓋到專案。
   - `git add / commit / push`。
   - 告訴 Windsurf：「請閱讀最新的 docs，之後依此為準。」

> 規則：**大改 → ZIP + 規格寫死在 docs 裡**。

---

### 3.2 小改（程式、小 bug、局部行為）

例如：

- sutra 頁 `<a id="item83"></a>` 沒出現在 markdown。
- 某個 adapter 欄位 mapping 要微調。
- 新增一個 pipeline helper function。
- 補一個測試案例。

**小改流程：**

1. 由 ChatGPT：
   - 產生一段「**給 Windsurf 的任務指令**」（用 code block 包起來）。
   - 內容包含：
     - 要讀的 docs（哪一節）。
     - 要動的檔案路徑。
     - 限制條件（那些型別／規則不能動）。
     - 要跑的測試指令＋預期結果。

2. 你：
   - 只需要 **複製這段指令貼給 Windsurf**。

3. Windsurf：
   - 根據指令修改程式碼。
   - 在 terminal 自動跑安全指令（`npx vitest`、`npm run lint`…）。
   - 更新 `docs/Windsurf_ChatGPT_NOTES.md` 對應小節，記錄：
     - 任務標題與日期。
     - 實際修改的檔案與重點邏輯。
     - 執行了哪些測試／結果如何。
     - 若有卡關，寫「無法解決的問題」段落。
   - 最後給你一段「**回報摘要**」，會特別為 ChatGPT 設計成可直接貼的文字。

4. 你：
   - 把這段回報摘要貼回 ChatGPT。
   - 覺得 OK 的時候再 `git add / commit / push`。

> 規則：**小改 → ChatGPT 給指令（code block），Windsurf 改程式＋寫 notes，回報摘要給 ChatGPT**。  
> 不一定要 re-ZIP，只要主規則沒變就好。

---

### 3.x 對話與文件分工：細節進 docs，對話保持精簡

- **對話窗保持精簡**
  - ChatGPT：在對話中只給「任務摘要 + 給 Windsurf 的短指令」，所有長篇規格與細節寫進 docs（例如 `PROJECT_TODO.md`、`WORKFLOW_*`、`CONTENT_SCHEMA.md`、`Windsurf_ChatGPT_NOTES.md`）。
  - Windsurf：回報時只需提供「本次任務代號 + 變更檔案列表 + 測試結果 + `[建議 git 指令]` 區塊」，不需要貼出完整思路或大段 diff。

- **細節全部寫在文件**
  - 任務規格與邏輯說明：
    - 由 ChatGPT 維護在 `docs/PROJECT_TODO.md`、`docs/WORKFLOW_CHATGPT_GITHUB_WINDSURF.md`、`docs/CONTENT_SCHEMA.md` 等文件。
  - 實作細節與重要決策：
    - 由 Windsurf 在 `docs/Windsurf_ChatGPT_NOTES.md` 中記錄每個 T 任務的小節。
  - 關鍵 terminal log：
    - 由 Windsurf 存到 `docs/terminal_logs/*.txt`，並在回報摘要中列出路徑。

- **Windsurf 儘量自動化，讓你一鍵執行**
  - 針對可以自動化的步驟（例如 `npm` / `vitest` / `tsc` / `git` 指令），Windsurf 儘量整理成「可直接複製執行」的一組命令。
  - 尤其是 `[建議 git 指令]` 區塊，會自動列出與本次 T 任務相關的檔案，讓你只需要在 IDE / 終端機裡核對一次，就能一鍵完成 `git add` / `commit` / `push`。

- **你只需要專注在三件事**
  1. 在 ChatGPT ↔ Windsurf 之間轉貼「任務指令」與「回報摘要」。
  2. 在 IDE 中檢視、核准並執行 Windsurf 提供的指令（特別是 `[建議 git 指令]`）。
  3. 在 GitHub 維護分支與整體專案節奏，其餘細節交給 ChatGPT + Windsurf 自動協作處理。

## 4. 每一輪任務的標準節奏

### Step 0：啟動新任務（你 → ChatGPT）

在 ChatGPT 這邊說明：

- 這次要處理什麼（例：sutra 規則 v1、blossom 單元、某個 bug）。
- （選擇性）希望這個任務在 notes 中的章節名稱，例如：
  - `## 2025-12-10 任務：sutra 規則 v2`

ChatGPT 會：

- 讀取需要的 docs（`PROJECT_TODO`、`Windsurf_ChatGPT_NOTES`、schema、rules）。
- 規劃任務拆分與限制條件。
- 給你一段「**給 Windsurf 的任務指令**」，用 code block 包起來，方便你一鍵複製。

---

### Step 1：你 → Windsurf

你只需要：

- 把 ChatGPT 給的指令整段複製，貼到 Windsurf。

Windsurf 收到後會：

- 閱讀指令中提到的 docs。
- 修改指令中提到的檔案。
- 在 terminal 執行安全的指令，例如：
  - `npx vitest`
  - `npx vitest tests/xxx.spec.ts`
  - `npm run lint`
- 在 `docs/Windsurf_ChatGPT_NOTES.md` 裡建立 / 更新本次任務的小節，內容包括：
  - 任務標題與日期。
  - 實際修改的檔案與重點邏輯。
  - 執行了哪些測試、結果如何。
  - 若有 卡關，就寫「無法解決的問題」段落。

---

### Step 2：Windsurf → 你（回報摘要）

任務完成後，Windsurf 會給你一段像這樣的文字：

```text
[Windsurf 回報摘要]
- 已更新：src/html/html-to-markdown.ts，調整 sutra 頁 anchor 輸出，
  現在會在 body_markdown 中輸出 `<a id="item83"></a>` + 原始編號文字。
- 測試：npx vitest tests/html/html-to-markdown.spec.ts
  - 4 個案例全部通過。
- 文件：已在 docs/Windsurf_ChatGPT_NOTES.md 增加本次任務小節，說明修改內容與測試結果。
```

你只要：

- 把這段回報摘要貼回 ChatGPT。

---

### Step 3：你 → ChatGPT（回報與下一步）

在 ChatGPT 對話中：

- 貼上 Windsurf 的回報摘要。
- 視情況說明是否已經 push 到 GitHub。

ChatGPT 會：

- 用回報摘要更新心中的專案狀態。
- 視需要：
  - 調整 / 追加 `docs/PROJECT_TODO.md` 的任務狀態。
  - 規劃下一步（下一個單元、下一個 pipeline…）。
  - 給你下一段要貼給 Windsurf 的指令。

---



### 4.x T 任務（T-0001, T-0002 …）的 lifecycle

> T-0001, T-0002, ... 是「可以拆給 Windsurf 的最小工作單位」。

1. **定義 T 任務（你 ↔ ChatGPT）**
   - 你在 ChatGPT 這邊說明想做的事與優先順序。
   - ChatGPT 會：
     - 先讀 `docs/PROJECT_TODO.md`、`docs/Windsurf_ChatGPT_NOTES.md`、schema / rules。
     - 在 `PROJECT_TODO.md` 裡新增一條 `T-XXXX` 任務（含：
       - 規格來源 docs
       - 要改的檔案路徑
       - 允許修改範圍
       - 驗收方式
     - 同時幫你想好一段「給 Windsurf 的短指令」。

2. **交辦 T 任務給 Windsurf（你 → Windsurf）**
   - 你只需要：
     - 把 ChatGPT 提供的短指令（code block）貼給 Windsurf。
     - 指令內容通常是：
       - 「請完成 `docs/PROJECT_TODO.md` 中的 T-000X，依照其中規格修改哪些檔案與跑哪些測試。」

3. **Windsurf 實作與記錄（Windsurf）**
   - Windsurf 依照 `PROJECT_TODO.md` 中 T-XXXX 的規格：
     - 修改程式與測試檔（只在允許修改的檔案內動手）。
     - 執行對應的 `npx vitest` / `npm run typecheck` / `npx tsc --noEmit` 等指令。
   - 並更新：
     - `docs/Windsurf_ChatGPT_NOTES.md`：加入本次任務的小節（實作細節、重要 decision）。
     - `docs/terminal_logs/…`：存放這次任務關鍵的 terminal log（tsc / vitest / 其他工具）。

4. **Windsurf 回報與你轉貼（Windsurf → 你 → ChatGPT）**
   - Windsurf 給你一段「回報摘要」，例如：
     - 本次任務代號（T-000X）。
     - 新增 / 更新的程式檔、測試檔路徑。
     - 新增的 docs / terminal_logs 路徑。
     - 測試與型別檢查是否通過。
   - 你只要把這段摘要貼回 ChatGPT 對話即可。

5. **ChatGPT 收尾與規劃下一步（ChatGPT）**
   - ChatGPT 會：
     - 將 `PROJECT_TODO.md` 中對應的 `T-XXXX` 標記為 ✅，並補上結果摘要。
     - 視需要調整 / 補充其他 docs 的說明（例如 CONTENT_SCHEMA / WORKFLOW）。
     - 幫你規劃下一個 T 任務（T-XXXX+1），並給出下一輪要貼給 Windsurf 的短指令。

> 總之：  
> - `PROJECT_TODO.md` 是「T 任務清單 + 狀態」。  
> - `Windsurf_ChatGPT_NOTES.md` 是「每個 T 任務的實作日誌」。  
> - 你只要負責在 ChatGPT 和 Windsurf 之間傳遞「短指令」與「回報摘要」，就能一路推進 T-0001, T-0002, ...。

### 4.y 每個 T 任務完成後的建議 git 流程（Windsurf → 你）

為了讓 GitHub 上的 repo 永遠貼近「最新已完成的 T 任務」，每一個 T-XXXX 任務收尾時，建議由 Windsurf 在回報摘要的最後，自動多附一段「建議 git 指令」，讓你可以在 IDE / 終端機中直接複製執行。

同時，**Windsurf 不會自動執行任何 `git add` / `git commit` / `git push`**，只會提供建議指令，由你在 IDE / 終端機中手動確認與執行。

#### 4.y.1 建議的 git 指令區塊格式

Windsurf 在每次任務完成時，回報摘要的結尾多附一段（範例）：

```text
[建議 git 指令]
git status

git add <這次變更相關的檔案列表>

git commit -m "feat: T-0005 news meta date/location"
git push origin <你的目標分支，例如 main>
```

#### 4.y.2 建議的 commit message 模板

```text
<type>: T-<序號> <簡短說明>

# 範例
feat: T-0005 news meta date/location
feat: T-0004 magazine-from-legacy skeleton
fix: T-0007 sutra verse edge-case handling
chore: T-0002 anycontent news/magazine types
docs: T-0001 teaching-from-legacy verses notes
```

> 重點：  
> - `type` 建議使用：`feat` / `fix` / `refactor` / `chore` / `docs`。  
> - 每個 T 任務理論上對應「至少一個 commit」，但你也可以視情況把多個小 T 任務合併成一個較大的 milestone commit。  
> - Windsurf 產生的「建議 git 指令」只是模板，你在執行前可以先看 `git status` / `git diff` 再決定要不要調整檔案列表與 commit message。  

## 5. Windsurf 自動跑 terminal 與「卡關」處理

### 5.1 Windsurf 可以自行執行的指令

**可以自動執行（不需你貼 terminal）：**

- 測試：
  - `npx vitest`
  - `npx vitest tests/xxx.spec.ts`
- Lint / build：
  - `npm run lint`
  - `npm run build`（視專案規模與效能情況決定是否常態執行；如 build 時間較長，可只在特定任務、且經你明確同意後再執行）

**需要你同意或手動執行：**

- `npm install ...`
- 可能會刪除 / 大量改動檔案的指令。
- 連線外部 API 的指令。

Windsurf 在這些情況會詢問你 / 要你按確認。

---

### 5.2 解不了的問題怎麼交接給 ChatGPT？

當 Windsurf 多次嘗試修正後仍然卡住時，會：

1. 在 `docs/Windsurf_ChatGPT_NOTES.md` 的該任務小節下新增一段：

   ```markdown
   #### 無法解決的問題

   - 問題描述：...
   - 重現步驟：
     - `npx vitest tests/...`
   - 關鍵 terminal 輸出（節錄）：
     - ...
   - 已嘗試過的修改：
     - 修改 A 檔案第幾行，結果如何。
     - 修改 B 檔案第幾行，結果如何。
   - 目前卡住的點 / 需要 ChatGPT 決策的地方：
     - ...
   ```

2. （選用）若問題較多，也可更新 `docs/UNRESOLVED_ISSUES.md` 做列表。

你只要：

- 把這段「無法解決的問題」及相關內容貼給 ChatGPT，  
  或在 ChatGPT 那邊說：「請閱讀 `docs/Windsurf_ChatGPT_NOTES.md` 裡最新任務的小節，幫我設計具體修改指令給 Windsurf。」

---

## 6. ChatGPT 開新對話建議開場模板

未來你在 ChatGPT 開新對話，可以這樣開場（可自行調整）：

```text
這是「中台世界舊站 → Headless CMS」專案。

專案 repo：ctcm-website-frontend

請先閱讀這些檔案（如果存在）：
- docs/COMPLETE_PROJECT_WORKFLOW.md
- docs/CONTENT_SCHEMA.md
- docs/HTML_TO_MARKDOWN_RULES_V4.md
- docs/PROJECT_TODO.md
- docs/Windsurf_ChatGPT_NOTES.md
- docs/WORKFLOW_CHATGPT_GITHUB_WINDSURF.md

目前最新任務小節是：
- docs/Windsurf_ChatGPT_NOTES.md 裡的「YYYY-MM-DD 任務：...」（以及之後的任務，如果有）。

請你：
1. 用自己的話重述目前專案狀態與最近幾次 Windsurf 的修改重點。
2. 建議我這一輪最適合先做哪一個小任務，並產生一段「可以直接貼給 Windsurf 的指令」。
3. 之後，每一次新的任務請都以同一個模式給我一段可複製的 Windsurf 指令。
```

---


---

## 6. ChatGPT 可見範圍與 docs snapshot / ZIP 交接

> 關鍵原則：**ChatGPT 只看得到「對話中貼出的內容」與「你上傳的檔案」。GitHub / Codex / Windsurf 的內部狀態，預設是不可見的。**

### 6.1 ChatGPT 能看到什麼？

ChatGPT 在這個對話中**看不到**：

- GitHub 上的檔案原文（即使 repo 是 public / 已連線）。
- Codex / Windsurf / 其他 Agent 在自己 sandbox 裡的檔案。

對 ChatGPT 而言，真相來源只有兩種：

1. 你貼進對話的文字（例如完整的 Markdown 段落、程式碼片段、回報摘要）。
2. 你在對話中上傳的檔案（例如 `docs/` snapshot ZIP、單一 `.md` 檔、log 檔）。

### 6.2 實作 Agent 完成任務後要做什麼？

每一個明確的 T 任務（例如 T-0005）完成後，實作 Agent 應該：

1. 在 repo 中更新對應的 docs：
   - 在 `docs/Windsurf_ChatGPT_NOTES.md` 新增一節，記錄：
     - 任務編號與簡述。
     - 實際修改的檔案與邏輯重點。
     - 執行過的測試指令與結果。
     - 若有尚未解決的問題，列在「未解決問題」小節。
   - 視需要更新 `docs/PROJECT_TODO.md`（將該 T 任務標記為 ✅，或新增後續子任務）。
   - 若有特殊情況，可更新 `docs/UNRESOLVED_ISSUES.md`。
   - 若有尚未決定是否寫入正式 workflow 的規則或設計，可以先記錄在 `docs/PENDING_DECISIONS.md`。

2. 在終端機 log 中，保留這次任務相關輸出：
   - 建議存成 `docs/terminal_logs/T-xxxx_<slug>_<tool>_<result>.txt`。
   - 例如：`docs/terminal_logs/T-0005_news-from-legacy_vitest_pass.txt`。

3. 若需要讓 ChatGPT 之後查看完整結果（包括 docs + log），請在專案根目錄建立（或重用）`snapshots/` 資料夾，
   並由實作 Agent 自動產生一個 docs snapshot ZIP（不加入 Git，只存在本機），內容至少包含：
   - 本次任務有修改的 `docs/*.md` 檔案。
   - 本次任務新增的 `docs/terminal_logs/*.txt` 檔案。

   建議檔名格式（放在 `snapshots/` 底下）：

   ```text
   snapshots/ctworld-docs-T-0005-2025-12-09-v1.zip
   ```

   命名規則說明：

   - `ctworld-docs`：專案代號＋只包含 docs 的 snapshot。
   - `T-0005`：對應的 T 任務編號。
   - `2025-12-09`：打包日期（使用當地時間即可）。
   - `v1`：當日第一次打包；若同一任務需要再次打包，可遞增為 `v2`, `v3`。

4. 產生一段簡短的 `[Windsurf 回報摘要]` 或 `[Agent 回報摘要]`，
   讓你可以直接貼回 ChatGPT 對話，並在摘要中註明此次 snapshot 檔名，例如：

   ```text
   本次 docs snapshot：snapshots/ctworld-docs-T-0005-2025-12-09-v1.zip
   ```

### 6.3 如何讓 ChatGPT 看到完整變更？

當你想讓 ChatGPT「真正看過這次任務的成果與 log」時，建議流程：

1. 確認實作 Agent 已完成 §6.2 的步驟，特別是：
   - docs 與 `docs/terminal_logs/` 都已更新。
   - 已在 `snapshots/` 底下產生對應的 docs snapshot ZIP（若該任務需要 ChatGPT 後續指導）。

2. 在本機找到對應的 ZIP 檔案，例如：
   - `snapshots/ctworld-docs-T-0005-2025-12-09-v1.zip`

3. 在 ChatGPT 對話中上傳該 ZIP，並簡單說明：
   - 本次任務編號（例如 T-0005）。
   - 希望 ChatGPT 做什麼（例如：檢查規則是否清楚、設計下一個 T 任務）。

之後 ChatGPT 回應時，會**以你上傳的 ZIP 內容為唯一權威版本**來設計新的任務與規則。

> 補充說明：ChatGPT 不會把舊對話中看過的 ZIP 當成長期檔案空間。  
> 若在某一個對話中需要重新檢視 docs / logs，請再次上傳對應的 docs snapshot ZIP。  
> 當 ChatGPT 嘗試讀取某個檔案但系統回報「檔案不存在」時，ChatGPT 應直接請你重新上傳 ZIP，而不是依照過去記憶臆測內容。



## 7. 總結

- **你**：決定方向＋複製貼上＋偶爾 `git` / `npm install`。
- **ChatGPT**：設計架構規格＋拆任務＋寫 docs（大改時提供 ZIP）。
- **Windsurf**：實作程式＋跑測試＋寫 `Windsurf_ChatGPT_NOTES.md`＋輸出回報摘要。

只要三方都照這份工作流程走：

- 對話視窗保持「輕量：決策＋指令＋回報」。
- 詳細規格與操作歷史集中在 Git repo 的 `docs/*.md`。
- 無論是你、ChatGPT 或 Windsurf，要接續工作時都能快速銜接。
