# CRAWL_FAILS

> 紀錄 crawler fetch/decode 失敗的 URL。歷史保存在 docs/QA/CRAWL_FAILS.jsonl（append-only）；本檔為最近一次執行的摘要。

目前尚無新紀錄（未跑 crawler 或無失敗）。
